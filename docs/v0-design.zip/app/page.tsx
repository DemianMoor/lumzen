"use client";

import { useState, useMemo, useEffect } from "react";
import {
  LayoutDashboard,
  BookOpen,
  Headphones,
  Sparkles,
  Music2,
  Stars,
  User,
  Settings,
  Bell,
  Search,
  Bookmark,
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Volume2,
  Moon,
  Timer,
  Maximize2,
  ChevronRight,
  Menu,
  X,
} from "lucide-react";

import {
  // Spiritual Guides
  IconSacredBook,
  IconChakraSpiral,
  IconMoonPhases,
  IconFlowerOfLife,
  IconAkashicRecords,
  // Audiobooks
  IconProphet,
  IconAncientScroll,
  IconHermetic,
  IconYinYang,
  IconInfiniteWisdom,
  // Affirmations
  IconMorningRise,
  IconTransformation,
  IconMirrorSelf,
  IconLotusChakra,
  IconBreathWaves,
  // Sound/Meditation
  IconFrequencyWaves,
  IconSingingBowl,
  IconThetaWave,
  IconLunarSleep,
  IconOmSymbol,
  // Celestial Tools
  IconTarotCard,
  IconOracleCrystal,
  IconCelticKnot,
  IconZodiacWheel,
  IconNatalChart,
} from "@/components/mystical-icons";

// ============ DATA ============
const user = {
  name: "Sarah",
  dayStreak: 14,
  totalDays: 30,
  sunSign: "Scorpio",
  moonSign: "Pisces",
  rising: "Leo",
};

const guides = [
  { id: 1, title: "The Seven Chakras", readTime: 12, level: "Beginner" },
  { id: 2, title: "Shadow Work Foundations", readTime: 18, level: "Intermediate" },
  { id: 3, title: "Moon Phase Rituals", readTime: 10, level: "Beginner" },
  { id: 4, title: "Sacred Geometry 101", readTime: 15, level: "Beginner" },
  { id: 5, title: "The Akashic Records", readTime: 20, level: "Advanced" },
];

const audiobooks = [
  { id: 1, title: "The Prophet", author: "Kahlil Gibran", duration: "1h 02m" },
  { id: 2, title: "As a Man Thinketh", author: "James Allen", duration: "38m" },
  { id: 3, title: "The Kybalion", author: "Three Initiates", duration: "3h 15m" },
  { id: 4, title: "The Tao Te Ching", author: "Lao Tzu", duration: "1h 24m" },
  { id: 5, title: "In Tune with the Infinite", author: "R.W. Trine", duration: "2h 45m" },
];

const affirmationActivities = [
  { id: 1, title: "Morning Abundance Flow", duration: "5 min", type: "Guided" },
  { id: 2, title: "21-Day Identity Shift", duration: "21 days", type: "Challenge" },
  { id: 3, title: "Mirror Work Journey", duration: "10 min", type: "Practice" },
  { id: 4, title: "Chakra Sequence", duration: "12 min", type: "Guided" },
  { id: 5, title: "Breathe & Affirm", duration: "8 min", type: "Breathwork" },
];

const soundTracks = [
  { id: 1, title: "432 Hz Deep Space", duration: "45:00", category: "Healing Frequencies" },
  { id: 2, title: "Tibetan Bowl Session", duration: "32:00", category: "Tibetan Bowls" },
  { id: 3, title: "Theta Wave Journey", duration: "60:00", category: "Binaural" },
  { id: 4, title: "Lunar Sleep Series", duration: "90:00", category: "Sleep" },
  { id: 5, title: "Om Chanting", duration: "20:00", category: "Chanting" },
];

const celestialTools = [
  { id: 1, title: "Daily Card Pull", type: "Tarot" },
  { id: 2, title: "Three-Card Spread", type: "Tarot" },
  { id: 3, title: "Celtic Cross Reading", type: "Tarot" },
  { id: 4, title: "Yes / No Oracle", type: "Oracle" },
  { id: 5, title: "Your Natal Chart", type: "Astrology" },
];

const solfeggioFrequencies = [
  { hz: 174, name: "Foundation", tagline: "Ground your energy", color: "#8b4513" },
  { hz: 285, name: "Restoration", tagline: "Recharge what&apos;s depleted", color: "#4a7c59" },
  { hz: 396, name: "Liberation", tagline: "Release what no longer serves", color: "#8b6fc9" },
  { hz: 417, name: "Transformation", tagline: "Break old patterns", color: "#d4758a" },
  { hz: 528, name: "Love", tagline: "Open the heart. Heal.", color: "#c4a35a" },
  { hz: 639, name: "Connection", tagline: "Harmonize relationships", color: "#6bcc9e" },
  { hz: 741, name: "Intuition", tagline: "Sharpen your inner voice", color: "#6b9fd4" },
  { hz: 852, name: "Return", tagline: "Come back to spiritual order", color: "#4db8a8" },
  { hz: 963, name: "Oneness", tagline: "Dissolve into the infinite", color: "#9b8ec4" },
];

const navItems = [
  { icon: LayoutDashboard, label: "Home", id: "home" },
  { icon: BookOpen, label: "Spiritual Guides", id: "guides" },
  { icon: Headphones, label: "Audiobooks", id: "audiobooks" },
  { icon: Sparkles, label: "Affirmations", id: "affirmations" },
  { icon: Music2, label: "Sound Temple", id: "sound" },
  { icon: Stars, label: "Celestial Tools", id: "celestial" },
];

const bottomNavItems = [
  { icon: User, label: "My Profile", id: "profile" },
  { icon: Settings, label: "Settings", id: "settings" },
];

// ============ COMPONENTS ============

function StarField() {
  const stars = useMemo(() => {
    return Array.from({ length: 150 }, (_, i) => ({
      id: i,
      top: Math.random() * 100,
      left: Math.random() * 100,
      size: i < 100 ? 1 : i < 130 ? 1.5 : Math.random() * 1 + 2,
      opacity: i < 100 ? 0.3 : i < 130 ? 0.5 : 0.7,
      duration: Math.random() * 5 + 2,
      delay: Math.random() * 5,
    }));
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {stars.map((star) => (
        <div
          key={star.id}
          className="absolute rounded-full bg-white"
          style={{
            top: `${star.top}%`,
            left: `${star.left}%`,
            width: `${star.size}px`,
            height: `${star.size}px`,
            opacity: star.opacity,
            animation: `twinkle ${star.duration}s ease-in-out infinite`,
            animationDelay: `${star.delay}s`,
            boxShadow: star.size > 2 ? "0 0 4px rgba(255,255,255,0.5)" : "none",
          }}
        />
      ))}
    </div>
  );
}

function NebulaBackground() {
  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {/* Nebula Gradient 1 - Top Left */}
      <div
        className="absolute"
        style={{
          top: "-10%",
          left: "-20%",
          width: "70vw",
          height: "70vw",
          background: "radial-gradient(circle, rgba(107,79,160,0.18) 0%, transparent 70%)",
          animation: "nebulaDrift 25s ease-in-out infinite alternate",
        }}
      />
      {/* Nebula Gradient 2 - Bottom Right */}
      <div
        className="absolute"
        style={{
          bottom: "-10%",
          right: "-10%",
          width: "60vw",
          height: "60vw",
          background: "radial-gradient(circle, rgba(77,184,168,0.10) 0%, transparent 70%)",
          animation: "nebulaDrift 25s ease-in-out infinite alternate-reverse",
        }}
      />
      {/* Lum-Glow Orb */}
      <div
        className="absolute top-1/4 left-1/2"
        style={{
          width: "400px",
          height: "400px",
          background: "radial-gradient(circle, rgba(196,163,90,0.08) 0%, transparent 70%)",
          filter: "blur(60px)",
          animation: "lumOrbit 30s linear infinite",
        }}
      />
    </div>
  );
}

function Sidebar({
  activeNav,
  setActiveNav,
  expanded,
  setExpanded,
}: {
  activeNav: string;
  setActiveNav: (id: string) => void;
  expanded: boolean;
  setExpanded: (expanded: boolean) => void;
}) {
  return (
    <aside
      className="fixed left-0 top-0 h-full z-50 transition-all duration-200 ease-out hidden md:flex flex-col"
      style={{
        width: expanded ? "220px" : "68px",
        background: "rgba(6,6,15,0.92)",
        backdropFilter: "blur(24px)",
        borderRight: "1px solid rgba(196,163,90,0.12)",
      }}
      onMouseEnter={() => setExpanded(true)}
      onMouseLeave={() => setExpanded(false)}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-5 py-6">
        <span className="text-[#c4a35a] text-xl">✦</span>
        <span
          className="font-display text-[15px] text-[#c4a35a] tracking-[0.1em] transition-opacity duration-200"
          style={{ opacity: expanded ? 1 : 0 }}
        >
          LumZen
        </span>
      </div>

      {/* Main Nav */}
      <nav className="flex-1 px-2 space-y-1">
        {navItems.map((item) => {
          const isActive = activeNav === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveNav(item.id)}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-all duration-200 group ${
                isActive ? "bg-[rgba(196,163,90,0.08)]" : "hover:bg-[rgba(255,255,255,0.03)]"
              }`}
              style={{
                borderLeft: isActive ? "3px solid #c4a35a" : "3px solid transparent",
              }}
              aria-label={item.label}
              aria-current={isActive ? "page" : undefined}
            >
              <item.icon
                size={20}
                className={`transition-colors ${isActive ? "text-[#c4a35a]" : "text-[#8f8daa] group-hover:text-[#f0eff8]"}`}
              />
              <span
                className={`font-sans text-sm transition-opacity duration-200 ${
                  isActive ? "text-[#f0eff8]" : "text-[#8f8daa] group-hover:text-[#f0eff8]"
                }`}
                style={{ opacity: expanded ? 1 : 0, whiteSpace: "nowrap" }}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>

      {/* Bottom Nav */}
      <div className="px-2 pb-4 space-y-1">
        {bottomNavItems.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveNav(item.id)}
            className="w-full flex items-center gap-3 px-3 py-3 rounded-lg transition-all hover:bg-[rgba(255,255,255,0.03)] group"
            aria-label={item.label}
          >
            <item.icon size={20} className="text-[#8f8daa] group-hover:text-[#f0eff8]" />
            <span
              className="font-sans text-sm text-[#8f8daa] group-hover:text-[#f0eff8] transition-opacity duration-200"
              style={{ opacity: expanded ? 1 : 0, whiteSpace: "nowrap" }}
            >
              {item.label}
            </span>
          </button>
        ))}

        {/* Member Badge */}
        <div
          className="mt-4 px-3 py-2 text-center transition-opacity duration-200"
          style={{ opacity: expanded ? 1 : 0 }}
        >
          <span className="font-display text-[10px] text-[#c4a35a] tracking-[0.15em] uppercase">
            ✦ LumZen Member
          </span>
        </div>
      </div>
    </aside>
  );
}

function MobileNav({
  activeNav,
  setActiveNav,
  mobileMenuOpen,
  setMobileMenuOpen,
}: {
  activeNav: string;
  setActiveNav: (id: string) => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}) {
  return (
    <>
      {/* Mobile Header */}
      <header className="md:hidden fixed top-0 left-0 right-0 z-50 px-4 py-3 flex items-center justify-between bg-[rgba(6,6,15,0.95)] backdrop-blur-xl border-b border-[rgba(196,163,90,0.12)]">
        <div className="flex items-center gap-2">
          <span className="text-[#c4a35a] text-lg">✦</span>
          <span className="font-display text-sm text-[#c4a35a] tracking-[0.1em]">LumZen</span>
        </div>
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="p-2 rounded-lg hover:bg-[rgba(255,255,255,0.05)]"
          aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
        >
          {mobileMenuOpen ? (
            <X size={24} className="text-[#f0eff8]" />
          ) : (
            <Menu size={24} className="text-[#f0eff8]" />
          )}
        </button>
      </header>

      {/* Mobile Menu Overlay */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed inset-0 z-40 bg-[rgba(6,6,15,0.98)] pt-16">
          <nav className="px-6 py-8 space-y-2">
            {[...navItems, ...bottomNavItems].map((item) => {
              const isActive = activeNav === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveNav(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-4 px-4 py-4 rounded-xl transition-all ${
                    isActive ? "bg-[rgba(196,163,90,0.12)]" : "hover:bg-[rgba(255,255,255,0.03)]"
                  }`}
                >
                  <item.icon size={22} className={isActive ? "text-[#c4a35a]" : "text-[#8f8daa]"} />
                  <span className={`font-sans text-base ${isActive ? "text-[#f0eff8]" : "text-[#8f8daa]"}`}>
                    {item.label}
                  </span>
                </button>
              );
            })}
          </nav>
        </div>
      )}

      {/* Mobile Bottom Nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-50 px-2 py-2 flex items-center justify-around bg-[rgba(6,6,15,0.95)] backdrop-blur-xl border-t border-[rgba(196,163,90,0.12)]">
        {navItems.slice(0, 5).map((item) => {
          const isActive = activeNav === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveNav(item.id)}
              className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-all ${
                isActive ? "text-[#c4a35a]" : "text-[#8f8daa]"
              }`}
              aria-label={item.label}
            >
              <item.icon size={20} />
              <span className="text-[10px] font-sans">{item.label.split(" ")[0]}</span>
            </button>
          );
        })}
      </nav>
    </>
  );
}

function Header({ isPlaying }: { isPlaying: boolean }) {
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour >= 5 && hour < 12) return { greeting: "Good morning", message: "The light is already within you." };
    if (hour >= 12 && hour < 17) return { greeting: "Good afternoon", message: "Stillness is available right now." };
    if (hour >= 17 && hour < 21) return { greeting: "Good evening", message: "The stars are beginning to listen." };
    return { greeting: "Rest well", message: "Your practice continues in your dreams." };
  };

  const { greeting, message } = getGreeting();
  const today = new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric" });

  return (
    <header
      className="sticky top-0 z-40 px-6 py-4 flex items-center justify-between gap-4"
      style={{
        background: "rgba(6,6,15,0.80)",
        backdropFilter: "blur(20px)",
        borderBottom: "1px solid rgba(196,163,90,0.10)",
      }}
    >
      {/* Left - Greeting */}
      <div className="hidden md:block">
        <h1 className="font-serif text-xl italic text-[#f0eff8]">
          {greeting}, {user.name} <span className="text-[#c4a35a]">✦</span>
        </h1>
        <p className="font-sans text-xs text-[#8f8daa] mt-0.5">
          {today} · 🌙 Waxing Crescent · Day {user.dayStreak} of your practice
        </p>
      </div>

      {/* Center - Search */}
      <div className="flex-1 max-w-md mx-auto">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#4a4866]" />
          <input
            type="text"
            placeholder="Search guides, tracks, readings..."
            className="w-full bg-[rgba(255,255,255,0.04)] border border-transparent rounded-full py-2 pl-10 pr-4 font-sans text-sm text-[#f0eff8] placeholder:text-[#4a4866] focus:outline-none focus:border-[#c4a35a] focus:ring-1 focus:ring-[#c4a35a] transition-all"
          />
        </div>
      </div>

      {/* Right - Actions */}
      <div className="flex items-center gap-4">
        <button className="relative p-2 rounded-full hover:bg-[rgba(255,255,255,0.05)] transition-colors" aria-label="Notifications">
          <Bell size={20} className="text-[#8f8daa]" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#c4a35a] rounded-full" />
        </button>
        <div
          className="w-10 h-10 rounded-full bg-gradient-to-br from-[#8b6fc9] to-[#c4a35a] flex items-center justify-center"
          style={{
            boxShadow: "0 0 0 3px rgba(196,163,90,0.4)",
            animation: isPlaying ? "pulse-soft 2s ease-in-out infinite" : "none",
          }}
        >
          <span className="font-serif text-sm text-white">{user.name[0]}</span>
        </div>
      </div>
    </header>
  );
}

function TodaysPracticeCard() {
  return (
    <div
      className="rounded-[20px] p-6 md:p-8 relative overflow-hidden"
      style={{
        background: "linear-gradient(135deg, rgba(107,79,160,0.22) 0%, rgba(77,184,168,0.08) 100%)",
        border: "1px solid rgba(196,163,90,0.25)",
      }}
    >
      {/* Noise texture overlay */}
      <div
        className="absolute inset-0 opacity-[0.03] pointer-events-none"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noiseFilter'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noiseFilter)'/%3E%3C/svg%3E")`,
        }}
      />

      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 relative z-10">
        {/* Left Content */}
        <div className="flex-1">
          <p className="font-display text-[11px] text-[#c4a35a] tracking-[0.2em] uppercase mb-3">
            ✦ YOUR PRACTICE TODAY
          </p>
          <h2 className="font-serif text-2xl md:text-4xl text-[#f0eff8] mb-2">
            {`"The light is already within you."`}
          </h2>
          <p className="font-sans text-sm text-[#8f8daa]">
            Day {user.dayStreak} of your journey. {"You're building something real."}
          </p>

          {/* Progress Ring */}
          <div className="flex items-center gap-4 mt-6">
            <div className="relative w-20 h-20">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="rgba(139,111,201,0.2)"
                  strokeWidth="3"
                />
                <path
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none"
                  stroke="#8b6fc9"
                  strokeWidth="3"
                  strokeDasharray={`${(user.dayStreak / user.totalDays) * 100}, 100`}
                  strokeLinecap="round"
                />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="font-mono text-xs text-[#f0eff8]">
                  {user.dayStreak}/{user.totalDays}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Start Pills */}
        <div className="flex flex-col gap-3">
          {[
            { icon: Stars, label: "Draw Today's Card", color: "#c4a35a", symbol: "✦" },
            { icon: Sparkles, label: "Morning Affirmation", color: "#8b6fc9", symbol: "✨" },
            { icon: Music2, label: "Enter Sound Temple", color: "#4db8a8", symbol: "🔮" },
          ].map((pill, idx) => (
            <button
              key={idx}
              className="flex items-center gap-3 px-5 py-3 rounded-full bg-[rgba(255,255,255,0.05)] border border-[rgba(255,255,255,0.12)] hover:scale-[1.03] hover:shadow-[0_0_20px_rgba(196,163,90,0.2)] transition-all duration-200"
            >
              <span>{pill.symbol}</span>
              <span className="font-sans text-sm text-[#f0eff8]">{pill.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function ContentCard({
  title,
  subtitle,
  duration,
  accentColor,
  icon: Icon,
  hovered,
  onHover,
  onLeave,
  isOtherHovered,
}: {
  title: string;
  subtitle: string;
  duration: string;
  accentColor: string;
  icon: React.ComponentType<{ color?: string; size?: number; className?: string }>;
  hovered: boolean;
  onHover: () => void;
  onLeave: () => void;
  isOtherHovered: boolean;
}) {
  return (
    <div
      className="flex-shrink-0 w-[240px] rounded-2xl overflow-hidden transition-all duration-200 cursor-pointer group"
      style={{
        background: "rgba(26,26,53,0.85)",
        backdropFilter: "blur(10px)",
        border: hovered ? `1px solid ${accentColor}66` : "1px solid rgba(255,255,255,0.06)",
        transform: hovered ? "translateY(-6px)" : "none",
        boxShadow: hovered ? `0 20px 60px ${accentColor}14` : "none",
        opacity: isOtherHovered && !hovered ? 0.6 : 1,
        filter: isOtherHovered && !hovered ? "brightness(0.8)" : "none",
      }}
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
    >
      {/* Image Area */}
      <div
        className="h-[140px] flex items-center justify-center relative"
        style={{
          background: `linear-gradient(135deg, ${accentColor}33 0%, ${accentColor}11 100%)`,
        }}
      >
        <Icon color={accentColor} size={64} className="opacity-90" />
        <button
          className="absolute top-3 right-3 p-1.5 rounded-full bg-[rgba(0,0,0,0.3)] opacity-0 group-hover:opacity-100 transition-opacity"
          aria-label="Bookmark"
        >
          <Bookmark size={14} className="text-[#f0eff8]" />
        </button>
      </div>

      {/* Content */}
      <div className="p-4">
        <span
          className="inline-block px-2 py-0.5 rounded-full text-[9px] font-display uppercase tracking-[0.1em] mb-2"
          style={{ background: `${accentColor}22`, color: accentColor }}
        >
          {subtitle.split(" ")[0]}
        </span>
        <h3 className="font-serif text-base text-[#f0eff8] mb-1 line-clamp-1">{title}</h3>
        <p className="font-mono text-[11px] text-[#4a4866]">{duration}</p>
        <div className="flex items-center justify-end mt-3">
          <span className="font-sans text-xs text-[#c4a35a] group-hover:underline">Begin →</span>
        </div>
      </div>
    </div>
  );
}

function ContentRow({
  label,
  title,
  subtitle,
  accentColor,
  items,
  getIcon,
}: {
  label: string;
  title: string;
  subtitle: string;
  accentColor: string;
  items: { title: string; subtitle: string; duration: string }[];
  getIcon: (index: number) => React.ComponentType<{ color?: string; size?: number; className?: string }>;
}) {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  return (
    <section className="mb-12">
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        <div>
          <p className="font-display text-[11px] tracking-[0.2em] uppercase mb-1" style={{ color: accentColor }}>
            ✦ {label}
          </p>
          <h2 className="font-serif text-2xl text-[#f0eff8]">{title}</h2>
          <p className="font-sans text-sm text-[#8f8daa]">{subtitle}</p>
        </div>
        <button className="font-sans text-sm text-[#c4a35a] hover:underline hidden md:block">
          See all →
        </button>
      </div>

      {/* Cards */}
      <div className="flex gap-4 overflow-x-auto pb-4 -mx-6 px-6 scrollbar-thin">
        {items.map((item, idx) => (
          <ContentCard
            key={idx}
            title={item.title}
            subtitle={item.subtitle}
            duration={item.duration}
            accentColor={accentColor}
            icon={getIcon(idx)}
            hovered={hoveredIndex === idx}
            onHover={() => setHoveredIndex(idx)}
            onLeave={() => setHoveredIndex(null)}
            isOtherHovered={hoveredIndex !== null && hoveredIndex !== idx}
          />
        ))}
      </div>
    </section>
  );
}

function CelestialToolsSection() {
  const [cardRevealed, setCardRevealed] = useState(false);
  const [hasChart, setHasChart] = useState(false);

  return (
    <section className="mb-12">
      <div className="flex items-center justify-between mb-4">
        <div>
          <p className="font-display text-[11px] text-[#8b6fc9] tracking-[0.2em] uppercase mb-1">✦ CELESTIAL TOOLS</p>
          <h2 className="font-serif text-2xl text-[#f0eff8]">The Cosmos Awaits</h2>
          <p className="font-sans text-sm text-[#8f8daa]">Ancient intelligence for your modern life</p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Daily Tarot */}
        <div
          className="rounded-2xl p-6 relative overflow-hidden"
          style={{
            background: "linear-gradient(135deg, rgba(139,111,201,0.15) 0%, rgba(196,163,90,0.08) 100%)",
            border: "1px solid rgba(139,111,201,0.3)",
          }}
        >
          <p className="font-display text-[11px] text-[#c4a35a] tracking-[0.2em] uppercase mb-3">✦ DAILY TAROT PULL</p>
          <h3 className="font-serif text-2xl text-[#f0eff8] mb-2">The Veil Is Thin at Dawn</h3>
          <p className="font-sans text-sm text-[#8f8daa] mb-6">
            Reveal your card for today. Let the image speak before the words do.
          </p>

          {/* Tarot Card */}
          <div className="flex justify-center mb-6">
            <div
              className="relative w-40 h-64 cursor-pointer perspective-1000"
              onClick={() => setCardRevealed(!cardRevealed)}
              style={{ perspective: "1000px" }}
            >
              <div
                className="w-full h-full transition-transform duration-700 relative"
                style={{
                  transformStyle: "preserve-3d",
                  transform: cardRevealed ? "rotateY(180deg)" : "rotateY(0)",
                }}
              >
                {/* Card Back */}
                <div
                  className="absolute inset-0 rounded-xl flex items-center justify-center"
                  style={{
                    backfaceVisibility: "hidden",
                    background: "linear-gradient(135deg, #1a1a35 0%, #0c0c1e 100%)",
                    border: "2px solid rgba(196,163,90,0.5)",
                    boxShadow: "0 10px 40px rgba(0,0,0,0.5)",
                  }}
                >
                  <div className="text-center">
                    <div className="w-24 h-32 mx-auto border-2 border-[#c4a35a] rounded-lg flex items-center justify-center mb-2">
                      <span className="text-[#c4a35a] text-3xl">✦</span>
                    </div>
                    <span className="font-display text-[10px] text-[#c4a35a] tracking-[0.15em]">LUMZEN</span>
                  </div>
                </div>
                {/* Card Front */}
                <div
                  className="absolute inset-0 rounded-xl flex flex-col items-center justify-center p-4"
                  style={{
                    backfaceVisibility: "hidden",
                    transform: "rotateY(180deg)",
                    background: "linear-gradient(135deg, #2a2a4a 0%, #1a1a35 100%)",
                    border: "2px solid rgba(196,163,90,0.5)",
                    boxShadow: "0 10px 40px rgba(0,0,0,0.5)",
                  }}
                >
                  <IconMoonPhases color="#c4a35a" size={72} className="mb-3" />
                  <h4 className="font-serif text-lg text-[#f0eff8]">The Moon</h4>
                  <p className="font-sans text-[10px] text-[#8f8daa] text-center mt-2">
                    Illusion, fear, the unconscious
                  </p>
                </div>
              </div>
            </div>
          </div>

          <button className="w-full py-3 rounded-full bg-[#c4a35a] text-[#06060f] font-sans text-sm font-medium hover:brightness-110 transition-all relative overflow-hidden group">
            <span className="relative z-10">{cardRevealed ? "Read Full Interpretation →" : "Reveal Today's Card ✦"}</span>
            <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity">
              <div
                className="absolute inset-0"
                style={{
                  background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent)",
                  animation: "shimmerSweep 1.5s ease-in-out infinite",
                }}
              />
            </div>
          </button>

          <p className="font-sans text-xs text-[#4a4866] text-center mt-4">Yesterday · The Moon</p>
        </div>

        {/* Natal Chart */}
        <div
          className="rounded-2xl p-6"
          style={{
            background: "linear-gradient(135deg, rgba(107,159,212,0.12) 0%, rgba(139,111,201,0.08) 100%)",
            border: "1px solid rgba(107,159,212,0.3)",
          }}
        >
          <p className="font-display text-[11px] text-[#c4a35a] tracking-[0.2em] uppercase mb-3">✦ YOUR NATAL CHART</p>
          <h3 className="font-serif text-2xl text-[#f0eff8] mb-2">Your Celestial Blueprint</h3>
          <p className="font-sans text-sm text-[#8f8daa] mb-6">
            Every planet was exactly where it needed to be the moment you arrived. This is what it means.
          </p>

          {!hasChart ? (
            <div className="space-y-4">
              <input
                type="text"
                placeholder="Date of birth"
                className="w-full bg-[rgba(255,255,255,0.04)] border border-[rgba(255,255,255,0.08)] rounded-lg py-3 px-4 font-sans text-sm text-[#f0eff8] placeholder:text-[#4a4866] focus:outline-none focus:border-[#c4a35a]"
              />
              <input
                type="text"
                placeholder="Time of birth"
                className="w-full bg-[rgba(255,255,255,0.04)] border border-[rgba(255,255,255,0.08)] rounded-lg py-3 px-4 font-sans text-sm text-[#f0eff8] placeholder:text-[#4a4866] focus:outline-none focus:border-[#c4a35a]"
              />
              <div className="relative">
                <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-[#4a4866]" />
                <input
                  type="text"
                  placeholder="City of birth"
                  className="w-full bg-[rgba(255,255,255,0.04)] border border-[rgba(255,255,255,0.08)] rounded-lg py-3 pl-10 pr-4 font-sans text-sm text-[#f0eff8] placeholder:text-[#4a4866] focus:outline-none focus:border-[#c4a35a]"
                />
              </div>
              <button
                onClick={() => setHasChart(true)}
                className="w-full py-3 rounded-full bg-[#c4a35a] text-[#06060f] font-sans text-sm font-medium hover:brightness-110 transition-all"
              >
                Generate My Chart ✦
              </button>
              <p className="font-sans text-xs text-[#4a4866] text-center">✦ Your data is private and never shared.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Zodiac Wheel */}
              <div className="w-32 h-32 mx-auto flex items-center justify-center">
                <IconZodiacWheel color="#8b6fc9" size={120} />
              </div>

              {/* Placements */}
              <div className="flex flex-wrap gap-2 justify-center">
                <span className="px-3 py-1 rounded-full bg-[rgba(196,163,90,0.2)] text-[#c4a35a] font-sans text-sm">
                  ☀️ Sun in {user.sunSign}
                </span>
                <span className="px-3 py-1 rounded-full bg-[rgba(107,159,212,0.2)] text-[#6b9fd4] font-sans text-sm">
                  🌙 Moon in {user.moonSign}
                </span>
                <span className="px-3 py-1 rounded-full bg-[rgba(139,111,201,0.2)] text-[#8b6fc9] font-sans text-sm">
                  ↑ Rising {user.rising}
                </span>
              </div>

              <p className="font-sans text-sm text-[#8f8daa] text-center">
                Your chart reveals a soul built for transformation. The Scorpio Sun seeks depth; the Pisces Moon feels
                everything; Leo rising presents it all with impossible grace.
              </p>

              <button className="w-full py-3 rounded-full border border-[#c4a35a] text-[#c4a35a] font-sans text-sm hover:bg-[rgba(196,163,90,0.1)] transition-all">
                Read Full Interpretation →
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function SolfeggioSection({
  activeFrequency,
  setActiveFrequency,
}: {
  activeFrequency: number | null;
  setActiveFrequency: (hz: number | null) => void;
}) {
  return (
    <section className="mb-12">
      <div className="mb-4">
        <p className="font-display text-[11px] text-[#4db8a8] tracking-[0.2em] uppercase mb-1">✦ THE FREQUENCY STUDIO</p>
        <h2 className="font-serif text-2xl text-[#f0eff8]">Nine Tones. Nine Doors.</h2>
        <p className="font-sans text-sm text-[#8f8daa]">Each Solfeggio frequency unlocks something different. Choose your key.</p>
      </div>

      <div className="flex gap-3 overflow-x-auto pb-4 -mx-6 px-6">
        {solfeggioFrequencies.map((freq) => {
          const isActive = activeFrequency === freq.hz;
          return (
            <button
              key={freq.hz}
              onClick={() => setActiveFrequency(isActive ? null : freq.hz)}
              className="flex-shrink-0 w-[120px] h-[160px] rounded-xl p-3 flex flex-col items-center justify-center text-center transition-all duration-200"
              style={{
                background: isActive
                  ? `radial-gradient(circle at center, ${freq.color}33 0%, ${freq.color}11 100%)`
                  : "rgba(26,26,53,0.6)",
                border: isActive ? `2px solid ${freq.color}` : "1px solid rgba(255,255,255,0.06)",
                animation: isActive ? "pulse-soft 2s ease-in-out infinite" : "none",
              }}
            >
              <span className="font-mono text-xl text-[#f0eff8]">{freq.hz}</span>
              <span className="font-mono text-[10px] text-[#8f8daa]">Hz</span>
              <span className="font-display text-[9px] text-[#c4a35a] uppercase tracking-wider mt-2">{freq.name}</span>
              <span className="font-sans text-[10px] text-[#4a4866] mt-1 line-clamp-2">{freq.tagline}</span>
              <div
                className="w-8 h-8 mt-2 rounded-full flex items-center justify-center transition-all"
                style={{
                  background: isActive ? freq.color : "rgba(255,255,255,0.05)",
                  boxShadow: isActive ? `0 0 15px ${freq.color}66` : "none",
                }}
              >
                {isActive ? <Pause size={14} className="text-white" /> : <Play size={14} className="text-[#8f8daa]" />}
              </div>
            </button>
          );
        })}
      </div>
    </section>
  );
}

function AudioPlayer({
  isPlaying,
  setIsPlaying,
  activeFrequency,
}: {
  isPlaying: boolean;
  setIsPlaying: (playing: boolean) => void;
  activeFrequency: number | null;
}) {
  const currentTrack = activeFrequency
    ? `${activeFrequency} Hz — ${solfeggioFrequencies.find((f) => f.hz === activeFrequency)?.name}`
    : "432 Hz Deep Space";
  const category = activeFrequency ? "Solfeggio Frequency" : "Sound Healing";

  return (
    <div
      className="fixed bottom-0 md:bottom-0 left-0 md:left-[68px] right-0 z-40 px-4 py-3 flex items-center gap-4 mb-16 md:mb-0"
      style={{
        background: "rgba(6,6,15,0.96)",
        backdropFilter: "blur(28px)",
        borderTop: "1px solid rgba(196,163,90,0.15)",
      }}
    >
      {/* Track Info */}
      <div className="flex items-center gap-3 min-w-0 flex-1 md:flex-initial md:w-64">
        <div
          className="w-10 h-10 rounded-lg flex-shrink-0"
          style={{
            background: "linear-gradient(135deg, #4db8a8 0%, #8b6fc9 100%)",
          }}
        />
        <div className="min-w-0">
          <p className="font-sans text-sm text-[#f0eff8] truncate">{currentTrack}</p>
          <p className="font-sans text-[11px] text-[#4a4866]">{category}</p>
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-2 md:gap-4 md:flex-1 justify-center">
        <button className="p-2 hover:bg-[rgba(255,255,255,0.05)] rounded-full hidden md:block" aria-label="Previous track">
          <SkipBack size={18} className="text-[#f0eff8]" />
        </button>
        <button
          onClick={() => setIsPlaying(!isPlaying)}
          className="p-3 bg-[rgba(255,255,255,0.1)] hover:bg-[rgba(255,255,255,0.15)] rounded-full transition-colors"
          aria-label={isPlaying ? "Pause" : "Play"}
        >
          {isPlaying ? <Pause size={20} className="text-[#f0eff8]" /> : <Play size={20} className="text-[#f0eff8]" />}
        </button>
        <button className="p-2 hover:bg-[rgba(255,255,255,0.05)] rounded-full hidden md:block" aria-label="Next track">
          <SkipForward size={18} className="text-[#f0eff8]" />
        </button>
      </div>

      {/* Progress */}
      <div className="hidden md:flex items-center gap-3 flex-1 max-w-xs">
        <span className="font-mono text-[11px] text-[#4a4866]">12:34</span>
        <div className="flex-1 h-1 bg-[rgba(255,255,255,0.1)] rounded-full overflow-hidden">
          <div className="w-1/4 h-full bg-[#4db8a8] rounded-full" />
        </div>
        <span className="font-mono text-[11px] text-[#4a4866]">45:00</span>
      </div>

      {/* Actions */}
      <div className="hidden md:flex items-center gap-2">
        <button className="p-2 hover:bg-[rgba(255,255,255,0.05)] rounded-full" aria-label="Volume">
          <Volume2 size={18} className="text-[#8f8daa]" />
        </button>
        <button className="p-2 hover:bg-[rgba(255,255,255,0.05)] rounded-full" aria-label="Save">
          <Bookmark size={18} className="text-[#8f8daa]" />
        </button>
        <button className="p-2 hover:bg-[rgba(255,255,255,0.05)] rounded-full" aria-label="Sleep timer">
          <Timer size={18} className="text-[#8f8daa]" />
        </button>
        <button className="p-2 hover:bg-[rgba(255,255,255,0.05)] rounded-full" aria-label="Expand player">
          <Maximize2 size={18} className="text-[#8f8daa]" />
        </button>
      </div>
    </div>
  );
}

// ============ MAIN DASHBOARD ============
export default function LumZenDashboard() {
  const [sidebarExpanded, setSidebarExpanded] = useState(false);
  const [activeNav, setActiveNav] = useState("home");
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeFrequency, setActiveFrequency] = useState<number | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  // When a frequency is selected, auto-play
  useEffect(() => {
    if (activeFrequency !== null) {
      setIsPlaying(true);
    }
  }, [activeFrequency]);

  if (!mounted) return null;

  return (
    <div className="min-h-screen bg-[#06060f] relative">
      {/* Animated Background */}
      <NebulaBackground />
      <StarField />

      {/* Sidebar (Desktop) */}
      <Sidebar
        activeNav={activeNav}
        setActiveNav={setActiveNav}
        expanded={sidebarExpanded}
        setExpanded={setSidebarExpanded}
      />

      {/* Mobile Navigation */}
      <MobileNav
        activeNav={activeNav}
        setActiveNav={setActiveNav}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
      />

      {/* Main Content */}
      <main
        className="relative z-10 pt-16 md:pt-0 pb-40 md:pb-24"
        style={{
          marginLeft: "0",
          paddingLeft: "0",
        }}
      >
        <div className="md:ml-[68px]">
          <Header isPlaying={isPlaying} />

          <div className="px-6 py-6 space-y-8">
            {/* Today's Practice Card */}
            <div style={{ animation: "fadeUp 0.6s ease-out forwards" }}>
              <TodaysPracticeCard />
            </div>

            {/* Celestial Tools (Tarot & Natal Chart) */}
            <div style={{ animation: "fadeUp 0.6s ease-out 0.08s forwards", opacity: 0 }}>
              <CelestialToolsSection />
            </div>

            {/* Content Rows */}
            <div style={{ animation: "fadeUp 0.6s ease-out 0.16s forwards", opacity: 0 }}>
              <ContentRow
                label="SPIRITUAL GUIDES"
                title="Deepen Your Understanding"
                subtitle="Wisdom you can actually use"
                accentColor="#c4a35a"
                items={guides.map((g) => ({
                  title: g.title,
                  subtitle: g.level,
                  duration: `${g.readTime} min read`,
                }))}
                getIcon={(i) => [IconSacredBook, IconChakraSpiral, IconMoonPhases, IconFlowerOfLife, IconAkashicRecords][i]}
              />
            </div>

            <div style={{ animation: "fadeUp 0.6s ease-out 0.24s forwards", opacity: 0 }}>
              <ContentRow
                label="SACRED AUDIOBOOKS"
                title="Voices Across Time"
                subtitle="The texts that shaped seekers before you"
                accentColor="#d4758a"
                items={audiobooks.map((a) => ({
                  title: a.title,
                  subtitle: a.author,
                  duration: a.duration,
                }))}
                getIcon={(i) => [IconProphet, IconAncientScroll, IconHermetic, IconYinYang, IconInfiniteWisdom][i]}
              />
            </div>

            <div style={{ animation: "fadeUp 0.6s ease-out 0.32s forwards", opacity: 0 }}>
              <ContentRow
                label="AFFIRMATION PRACTICE"
                title="Rewire Your Inner World"
                subtitle="Daily activities for lasting change"
                accentColor="#6bcc9e"
                items={affirmationActivities.map((a) => ({
                  title: a.title,
                  subtitle: a.type,
                  duration: a.duration,
                }))}
                getIcon={(i) => [IconMorningRise, IconTransformation, IconMirrorSelf, IconLotusChakra, IconBreathWaves][i]}
              />
            </div>

            <div style={{ animation: "fadeUp 0.6s ease-out 0.4s forwards", opacity: 0 }}>
              <ContentRow
                label="MEDITATION & SOUND"
                title="The Sound Temple"
                subtitle="Frequencies that restore. Silence that speaks."
                accentColor="#4db8a8"
                items={soundTracks.map((s) => ({
                  title: s.title,
                  subtitle: s.category,
                  duration: s.duration,
                }))}
                getIcon={(i) => [IconFrequencyWaves, IconSingingBowl, IconThetaWave, IconLunarSleep, IconOmSymbol][i]}
              />
            </div>

            <div style={{ animation: "fadeUp 0.6s ease-out 0.48s forwards", opacity: 0 }}>
              <SolfeggioSection activeFrequency={activeFrequency} setActiveFrequency={setActiveFrequency} />
            </div>
          </div>
        </div>
      </main>

      {/* Audio Player */}
      <AudioPlayer isPlaying={isPlaying} setIsPlaying={setIsPlaying} activeFrequency={activeFrequency} />
    </div>
  );
}
